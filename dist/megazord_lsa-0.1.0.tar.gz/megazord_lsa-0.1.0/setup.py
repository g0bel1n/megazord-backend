from setuptools import setup

setup(
    name='megazord_lsa',
    version='0.1.0',
    description='SoftNext DeepL Project',
    url='https://github.com/iSab01/megazord',
    author='Lucas Saban',
    author_email='lucas.saban@ensae.fr',
    license='Sofnext',
    packages=['megazord_lsa']


)